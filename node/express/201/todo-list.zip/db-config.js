// For production, create this file with
// the production database configuration

module.exports = {
  database: 'todo_list_db'
};
