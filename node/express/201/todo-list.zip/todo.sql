CREATE TABLE task (
  id serial PRIMARY KEY,
  description varchar,
  done boolean
);
